import logo from './logo.svg';
import React,{useState} from 'react';
import './App.css';
import ExpenseItemList from './components/Expenses/ExpenseItemList';
import NewExpense from './components/Expenses/NewExpense/NewExpense';

const DUMMY_EXPENSES = [
  {id:'e1',title:'Car Expenses',amount:670.89,date:new Date(2022,4,7)},
  {id:'e2',title:'Mobile Expenses',amount:90.78,date:new Date(2022,7,12)},
  {id:'e3',title:'House Expenses',amount:100.7,date:new Date(2021,2,29)},
  {id:'e4',title:'PF Expenses',amount:550.00,date:new Date(2020,12,20)},
]
const App = () => {
  const [expenses,setExpenses] = useState(DUMMY_EXPENSES);
  const addNewExpensesInList = (expense) =>{
    setExpenses(prevExpenses =>{
      return [expense,...prevExpenses];
    });
  }
  return (
    <div>
       <NewExpense onNewExpenseList={addNewExpensesInList}/>
       <ExpenseItemList item={expenses}/>
    </div>
  );
}

export default App;
