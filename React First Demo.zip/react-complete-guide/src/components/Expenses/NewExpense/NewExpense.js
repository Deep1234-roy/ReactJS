import React, { useState } from 'react';
import './NewExpense.css';
import ExpenseForm from './ExpenseForm';
const NewExpense = (props) => {
    const [isEditing, setIsEditing] = useState(false);
    
    const saveNewExpenses = (enteredNewExpenses) =>{
        const NewExpenses = {
            ...enteredNewExpenses,
            id: Math.random().toString()
        }
        props.onNewExpenseList(NewExpenses);
        setIsEditing(false);
       // console.log(NewExpenses);
    }
    
    const startEditingHandler = () => {
        setIsEditing(true);
    }
    const hideEditingHandler = () =>{
        setIsEditing(false);
    }
    
    
    
    return (
        <div className="new-expense">
            {!isEditing && <button onClick={startEditingHandler}>Add New Expenses</button>}
            {isEditing && <ExpenseForm 
            onSaveNewExpenses ={saveNewExpenses} 
            onCancel={hideEditingHandler}
            />
            }
        </div>
    )
}
export default NewExpense;
